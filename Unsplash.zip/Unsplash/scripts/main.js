async function makeAPICall(url)
{
    try {
        
      let res= await fetch(url);
  
      let data = await res.json();
      return data;
  
    } catch (error) {
        console.log(error);
    }
}
    function pictures(data, parent){
           data.forEach((element) => {
            let div= document.createElement('div');

            let img= document.createElement('img');
            img.src= element.urls.small;

            let name= document.createElement("p");
            name.innerText= element.user.name;

            div.append(img, name);
            parent.append(div);
           });
    }
    
  
  export { makeAPICall, pictures} ;
