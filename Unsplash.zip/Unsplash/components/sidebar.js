function sidebar(){
    return `
    <div> Menu</div>
    <div> Login</div>
    <div> signup</div>
    <input type="text" id="searchbar" placeholder="Write here & Press Enter">
    <div>News</div>
    <div> API</div>
    
    `;



};
export default sidebar;